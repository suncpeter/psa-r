#' Hodges-Lehmann Aligned Rank Test (HodgesL)
#'
#'Computes the average treatment effect (ATE) from the matched sample generated using Optimal/Full matching algorithm.
#'@param match.data                                                     matched dataset resulting from Optimal or Full matching algorithm
#'@param N                                                              total number of matched sample
#'@return ATE                                                           Average Treatment Effect
#'@return z score                                                       test statistic
#'@return significance for the z score
#'@examples
#'names(match.data)[names(match.data)=="score09"]="y"      # Rename the outcome variable according to your dataset
#'names(match.data)[names(match.data)=="treatm"]="treat"   # Rename the treatment variable according to your dataset
#'HodgesL (match.data, 322)
#'@export

HodgesL<-function(match.data, N)
{
  new<-match.data[order(match.data$subclass),]
  mytable <- table(match.data$subclass,match.data$treat)
  mytable <- table(match.data$subclass,match.data$treat)
  size <-tapply(match.data$treat, match.data$subclass, length)
  aven <-size/N
  aggdata <-aggregate(match.data, by=list(match.data$subclass, match.data$treat
  ),FUN=mean, na.rm=TRUE)
  aggdata
  treated <-(aggdata$treat==1)
  diffY<- (aggdata$score[treated] - aggdata$score[!treated])
  ATEtab<-data.frame(size, aven, diffY)
  ATEtab$ATE <-(ATEtab$aven*(ATEtab$diffY))
  ATE <-sum(ATEtab$ATE)
  n <-tapply(match.data$treat, match.data$subclass, length)
  write.csv(mytable, file = "data.csv")
  data<-read.csv("data.csv")
  names(data)[names(data)=="X"]="subclass"
  names(data)[names(data)=="X0"]="control"
  names(data)[names(data)=="X1"]="treat"
  aggdata2 <-aggregate(match.data, by=list(match.data$subclass),FUN=mean, na.rm=TRUE)
  final <- merge(new, aggdata2,by="subclass")
  diff<-final$score.x-final$score.y
  final <- cbind(final, diff)
  r<-rank(diff)
  final <- cbind(final, r)
  ki <- tapply(final$r, list(final$subclass),mean, na.rm=TRUE)
  data<-cbind(data,ki )
  cki.unit <-data$control*data$ki
  tki.unit<-data$treat*data$ki
  data<-cbind(data,cki.unit, tki.unit )
  final <- merge(final, data, by="subclass")
  var0<- ((final$r-final$ki)^2)
  var1 <-tapply(var0, final$subclass, sum)
  var2<-((data$control)*(data$treat))/(n*(n-1))
  var<-var1 *var2
  data<-cbind(data,var )
  m_block<- sum(tki.unit)
  v_block <- sum(var)
  W <-tapply(final$r, list(final$subclass, final$treat.x), sum, na.rm=TRUE)
  data<-cbind(data,W)
  names(data)[names(data)=="0"]="W_ct"
  names(data)[names(data)=="1"]="W_tx"
  z<-((sum(data$W_tx)-(m_block))/(sqrt(v_block)))
  prob<-2*pnorm(-abs(z))
  if (prob <.05){
    prob <-"significant"
  } else{
    prob<-"nonsignificant"
  }
  return (setNames((list(ATE, z, prob)),c("ATE", "z scores", "p-value")))
}


